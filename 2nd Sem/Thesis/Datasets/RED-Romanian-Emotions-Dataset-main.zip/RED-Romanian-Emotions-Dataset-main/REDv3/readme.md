# RED - Romanian Emotions Datasets v3
