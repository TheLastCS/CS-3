from torch.utils.data import Dataset, DataLoader
import torch

class RED(Dataset):

    def __init__(self, texts, emotions, tokenizer, max_len):
        self.texts = texts
        self.emotions = emotions
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, item):
        text = str(self.texts[item])
        emotion = self.emotions[item]
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_len,
            return_token_type_ids=False,
            pad_to_max_length=True,
            #padding='max_length',
            return_attention_mask=True,
            return_tensors='pt',
        )

        return {
            'text': text,
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'emotions': torch.tensor(emotion, dtype=torch.long)
        }